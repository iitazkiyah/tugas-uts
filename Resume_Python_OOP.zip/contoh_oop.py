# Contoh Implementasi Python OOP berdasarkan materi

class Kampus:
    # Class attributes
    nama = ""
    alamat = ""


class Mahasiswa:
    # Class attributes
    nim = 0
    nama = ""

    # Method dengan parameter self
    def perkenalan(self):
        print(f"Halo nama saya {self.nama}")

    # Method dengan parameter tambahan
    def hello(self, nama):
        print(f"Halo {nama}, nama saya {self.nama}")


# Instansiasi object
kampus1 = Kampus()
kampus1.nama = "Universitas Indonesia"
kampus1.alamat = "Depok"

mahasiswa1 = Mahasiswa()
mahasiswa1.nim = 123456
mahasiswa1.nama = "Arya"

mahasiswa2 = Mahasiswa()
mahasiswa2.nim = 123457
mahasiswa2.nama = "Budi"

# Memanggil method
mahasiswa1.perkenalan()
mahasiswa1.hello("Budi")

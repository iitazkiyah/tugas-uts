# Resume Materi: Python Object-Oriented Programming (OOP)

## 1. Pengertian Class dan Object
* **Class**: Blueprint atau template untuk membuat *object* (seperti cetakan kue yang dapat digunakan untuk membuat banyak kue dengan bentuk serupa).
* **Object**: *Instance* atau hasil "produksi" dari blueprint *class*. Setiap *object* memiliki struktur data dan *behavior* yang sama sesuai *class*-nya, namun dapat memiliki nilai (*value*) yang berbeda.

---

## 2. Attributes (Atribut)
* **Attributes**: Variabel yang menyimpan data di dalam sebuah *object*.
* **Instance Attribute**: Atribut yang didefinisikan langsung pada *object* hasil instansiasi (misalnya `mahasiswa1.nim = 123456`). Atribut ini hanya dimiliki oleh *object* tersebut dan tidak otomatis ada pada *object* lain dari *class* yang sama.
* **Class Attribute**: Atribut yang didefinisikan langsung di dalam *class* (misalnya `nim = 0`, `nama = ""` di dalam `class Mahasiswa`). Atribut ini secara *default* dimiliki oleh semua *object* hasil instansiasi *class* tersebut.

---

## 3. Methods (Metode)
* **Methods**: Fungsi (*functions*) yang berada di dalam *class* dan dapat dipanggil oleh *object*.
* **Parameter `self`**: Parameter wajib/khusus yang merujuk pada *instance* atau *object* yang sedang memanggil *method* tersebut (contoh: `self.nama` mengakses atribut `nama` milik *object* pemanggil).
* **Method dengan Parameters**: Selain `self`, *method* dapat menerima parameter tambahan layaknya fungsi biasa di Python (contoh: `def hello(self, nama):`).

---

## 4. Naming Conventions (Aturan Penamaan)
* **Class Names**: Menggunakan format **PascalCase** (contoh: `Mahasiswa`, `MataPelajaran`, `Mobil`, `KategoriBarang`).
* **Method Names**: Menggunakan format **snake_case** (contoh: `perkenalan()`, `lari_ke_depan()`, `jalankan()`).
* **Attribute Names**: Menggunakan format **snake_case** (contoh: `nama`, `nama_depan`, `nama_belakang`).
